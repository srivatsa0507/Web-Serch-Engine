# Java Web Search Engine

COMP 8547 - ADVANCED COMPUTING CONCEPTS PROJECT

Instructed by Dr. Mahdi Firoozjaei

Main features of web search engine - 
Web Crawler – Jitender Kumar (110093450)
Boyer Moore - Srivatsa Lasya Priya Oruganti (110094384)
Search word - Parmjot Singh Chahal (110093450)
Edit Distance -Parul Arora (110091276)